1Click-resize-to-half
